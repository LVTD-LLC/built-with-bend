# Built with Bend media kit

## Set up the X profile

Upload `social/x-profile.png` (400 × 400) and `social/x-header.jpg` (1500 × 500). Use the default centered crops. The bio and image descriptions are in `press/copy.md`.

## Choose an asset

| Use | File |
| --- | --- |
| Website masthead or partner credit | `logos/logo-primary.svg` |
| Transparent mark | `logos/mark-primary.svg` |
| Single-color or dark-background logo | `logos/*-ink.svg` or `logos/*-reverse.svg` |
| Raster logo for a slide or editor | Matching transparent PNG in `logos/` |
| Link preview | `social/link-preview.jpg` (1200 × 630) |
| Square announcement | `social/square-post.jpg` (1080 × 1080) |
| Reusable project feature | `source/project-spotlight-template.svg` |
| Logo usage, colors and typography | `press/brand-guide.pdf` |

## Website icons

Copy the contents of `icons/` to a public directory. The example assumes the site root. Keep the manifest alongside its PNGs so its relative URLs resolve.

```html
<link rel="icon" href="/favicon.ico" sizes="16x16 32x32 48x48">
<link rel="icon" href="/favicon.svg" type="image/svg+xml" sizes="any">
<link rel="apple-touch-icon" href="/apple-touch-icon.png" sizes="180x180">
<link rel="manifest" href="/site.webmanifest">
```

## Artwork and editing

The logo SVGs contain outlined lettering. The social SVGs also use paths and embed the artwork for reliable reproduction. Open the project spotlight template in a vector editor to change its live text, replace the project name and creator, and export a square PNG. The original header artwork is in `source/folded-paper.jpg`.

The visual identity extends the directory’s existing palette. Site details and curator credit come from [the directory](https://builtwithbend.com/) and its [design system](https://github.com/lvtd-llc/built-with-bend/blob/main/DESIGN.md). The paper sculpture was generated with built-in ImageGen. See the prompt in `source/art-direction.txt`.

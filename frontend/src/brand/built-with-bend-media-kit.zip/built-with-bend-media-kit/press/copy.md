# Built with Bend

## One line

An independent directory of projects built with Bend 2.

## X bio

Explore what people are building with Bend 2. A hand-picked directory of apps, games, tools, libraries, and experiments. Curated by LVTD.

## About

Built with Bend is an independent directory curated by LVTD. It helps developers discover what people make with Bend 2, from games and websites to libraries and research experiments. Each listing describes the project and links to its original sources so readers can explore the work and its creators.

## Links

- Directory and project submissions: https://builtwithbend.com/
- Weekly newsletter: https://builtwithbend.com/newsletter/
- X handle: @builtwithbend
- Curator: https://lvtd.dev/
- Public repository: https://github.com/lvtd-llc/built-with-bend

## Image descriptions

- Profile picture: A cream lowercase b with angular folds on a terracotta background.
- X header: The Built with Bend logo and the line “An independent directory of Bend 2 projects” beside a folded terracotta paper sculpture.
- Link preview: “What people build with Bend.” A red folded-paper loop appears on the right.
